<?php 

    // Custom Libraries
    require_once 'libs/Detector.php';
    require_once 'libs/IP_Info.php';
    require_once 'libs/Page_Loader.php';
    require_once 'libs/Client_IP.php';
    require_once 'db.php';
    require_once 'settings.php';
    require_once 'router.php';
    
?>