<?php

$servername = "localhost";
$username = "ipdatabase";
$password = "ipdatabase";
$dbname = "ipdatabase";